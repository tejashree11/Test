package com.example.retrofitrv

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.retrofitrv.Adapter.MyDogAdapter
import com.example.retrofitrv.Common.Common
import com.example.retrofitrv.Interface.RetrofitService
import com.example.retrofitrv.Model.DogModel
import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var mService : RetrofitService
    lateinit var layoutManager: LinearLayoutManager
    lateinit var adapter : MyDogAdapter
    lateinit var dialog: AlertDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mService = Common.retrofitService

        recyclerDogList.setHasFixedSize(true)
        layoutManager = LinearLayoutManager(this)
        recyclerDogList.layoutManager = layoutManager

        dialog = SpotsDialog.Builder().setCancelable(false).setContext(this).build()

        getAllMovieList()
    }

    private fun getAllMovieList() {
        dialog.show()

        mService.getDogList().enqueue(object : Callback<MutableList<DogModel>> {
            override fun onFailure(call: Call<MutableList<DogModel>>, t: Throwable) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onResponse(call: Call<MutableList<DogModel>>, response: Response<MutableList<DogModel>>) {
                adapter = MyDogAdapter((baseContext), response.body() as MutableList<DogModel>)
                adapter.notifyDataSetChanged()
                recyclerDogList.adapter = adapter

                dialog.dismiss()
            }

        })
    }
}