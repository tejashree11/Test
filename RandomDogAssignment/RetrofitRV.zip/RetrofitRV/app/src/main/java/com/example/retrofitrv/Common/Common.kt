package com.example.retrofitrv.Common

import com.example.retrofitrv.Interface.RetrofitService
import com.example.retrofitrv.Retrofit.RetrofitClient

object Common {
    private val BASE_URL = "https://dog.ceo/api/breeds/image/random/"
    val retrofitService:RetrofitService
    get()=RetrofitClient.getClient(BASE_URL).create(RetrofitService::class.java)


}