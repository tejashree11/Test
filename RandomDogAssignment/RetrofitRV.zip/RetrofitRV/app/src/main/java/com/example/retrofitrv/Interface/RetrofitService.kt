package com.example.retrofitrv.Interface

import android.graphics.Movie
import com.example.retrofitrv.Model.DogModel
import retrofit2.Call
import retrofit2.http.GET

interface RetrofitService {
    @GET("marvel")
    fun getDogList(): Call<MutableList<DogModel>>
}