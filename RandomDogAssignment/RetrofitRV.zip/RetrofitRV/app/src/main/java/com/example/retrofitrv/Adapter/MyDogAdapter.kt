package com.example.retrofitrv.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitrv.Model.DogModel
import com.example.retrofitrv.R
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.layout_dog_item.view.*


class MyDogAdapter(private val context: Context, private val dogList: MutableList<DogModel>): RecyclerView.Adapter<MyDogAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var itemView = LayoutInflater.from(context).inflate(R.layout.layout_dog_item, parent, false)
        return MyViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return dogList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        Picasso.get().load(dogList[position].imageurl).into(holder.image)


    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var image : ImageView


        init {
            image = itemView.image_dog

        }
    }
}