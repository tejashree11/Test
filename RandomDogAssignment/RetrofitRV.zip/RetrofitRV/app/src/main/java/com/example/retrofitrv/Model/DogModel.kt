package com.example.retrofitrv.Model

class DogModel {
    var imageurl: String? = null

}